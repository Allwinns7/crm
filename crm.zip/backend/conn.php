<?php
date_default_timezone_set("Asia/Kolkata");
$servername = "localhost";
$username = "news7tam_crmadm";
$password = "News7@1244";
$dbname = "news7tam_crm";
$conn = new mysqli($servername, $username, $password, $dbname);
