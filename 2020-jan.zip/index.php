<?php
   include('includes/auth.inc');
   include('backend/conn.php');

   $order_sql = $conn->query("SELECT * FROM tbl_order WHERE order_converted=1");
   $order_count = mysqli_num_rows($order_sql);

   $oppr_sql = $conn->query("SELECT * FROM oppurtunity ");
   $oppr_count = mysqli_num_rows($oppr_sql);

   $lead_sql = $conn->query("SELECT * FROM leads");
   $lead_count = mysqli_num_rows($lead_sql);

   $invc_sql = $conn->query("SELECT * FROM tbl_order WHERE order_converted=0");
   $invc_count = mysqli_num_rows($invc_sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CRM Dashboard</title>
      <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
      <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/plugins/lobipanel/lobipanel.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/plugins/pace/flash.css" rel="stylesheet" type="text/css"/>
      <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
      <link href="assets/themify-icons/themify-icons.css" rel="stylesheet" type="text/css"/>
      <link href="assets/plugins/emojionearea/emojionearea.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/plugins/monthly/monthly.css" rel="stylesheet" type="text/css"/>
      <link href="assets/dist/css/stylecrm.css" rel="stylesheet" type="text/css"/>
   </head>
   <body class="hold-transition sidebar-mini">
      <div id="preloader">
         <div id="status"></div>
      </div>
      <div class="wrapper">
         <?php 
            include('includes/topbar.inc');
            include('includes/sidebar.inc');
         ?>                                                                                                        
         <div class="content-wrapper">
            <section class="content-header">
               <div class="header-icon">
                  <i class="fa fa-dashboard"></i>
               </div>
               <div class="header-title">
                  <h1>CRM Admin Dashboard</h1>
                  <small>Very detailed & featured admin.</small>
               </div>
            </section>
            <section class="content">
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox1">
                        <div class="statistic-box">
                           <i class="fa fa-user-plus fa-3x"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php echo $order_count;?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <h3> Total Orders</h3>
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox2">
                        <div class="statistic-box">
                           <i class="fa fa-user-secret fa-3x"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php echo $oppr_count;?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <h3>  Total Opportunity</h3>
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox3">
                        <div class="statistic-box">
                           <i class="fa fa-money fa-3x"></i>
                           <div class="counter-number pull-right">
                              <i class="ti ti-money"></i><span class="count-number"><?php echo $lead_count;?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <h3>  Total Leads</h3>
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox4">
                        <div class="statistic-box">
                           <i class="fa fa-files-o fa-3x"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php echo $invc_count;?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <h3> Total Invoices</h3>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-xs-12 col-sm-8">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Upcoming Events</h4>
                           </div>
                        </div>
                        <div class="panel-body" id="cal_list">
                           
                           
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-4">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Calender</h4>
                           </div>
                        </div>
                        <div class="panel panel-bd">
                           <div class="panel-body">
                              <div class="monthly_calender">
                                 <div class="monthly" id="m_calendar"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Accounts</h4>
                           </div>
                        </div>
                        <div class="panel-body" id="accounts_list">
                     
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Contacts</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="Workslist">
                              <div class="worklistdate">
                                 <table class="table table-hover">
                                    <thead>
                                       <tr>
                                          <th>Contact Name</th>
                                          <th>Email</th>
                                          <th>Phone</th>
                                       </tr>
                                    </thead>
                                    <tbody id="contact_list">
                                       
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Leads</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="Workslist">
                              <div class="worklistdate">
                                 <table class="table table-hover">
                                    <thead>
                                       <tr>
                                          <th>Name</th>
                                          <th>Accounts</th>
                                          <th>View</th>
                                       </tr>
                                    </thead>
                                    <tbody id="leads_list">
                                    
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Opportunity</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="Workslist">
                              <div class="worklistdate">
                                 <table class="table table-hover">
                                    <thead>
                                       <tr>
                                          <th>Name</th>
                                          <th>Stage</th>
                                          <th>Source</th>
                                       </tr>
                                    </thead>
                                    <tbody id="opps_list">
                                       
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </div>
         <?php include('includes/footer.inc');?>
      </div>
      <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
      <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
      <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
      <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
      <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
      <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
      <script src="assets/dist/js/custom.js" type="text/javascript"></script>
      <script src="assets/plugins/chartJs/Chart.min.js" type="text/javascript"></script>
      <script src="assets/plugins/counterup/waypoints.js" type="text/javascript"></script>
      <script src="assets/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
      <script src="assets/plugins/monthly/monthly.js" type="text/javascript"></script>
      <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
      <script>
         $(document).ready(function(){

            // Getting all contact details
            $.ajax({
               url: 'backend/getallcontacts.php',
               type: 'GET',
               async:false,
               success: function(data){
                   var result = JSON.parse(data);
                   var list = "";
                   for(var ls=0; ls<result.length;ls++) {
                        list += "<tr><th scope='row'>"+(ls+1)+". "+result[ls].name+"</th><td>"+result[ls].email+"</td><td>"+result[ls].phone+"</td></tr>";
                   }
                  $('#contact_list').html(list);
               },
               error: function(xhr, textStatus, errorThrown) {
                   alert('Network Error, Try Later!!');
                   return false;
               }
             });

             // Getting all accounts details 

             $.ajax({
               url: 'backend/getallaccounts.php',
               type: 'GET',
               async:false,
               success: function(data){
                   var result = JSON.parse(data);
                   var list = "";
                   for(var ls=0; ls<result.length;ls++) {
                        list += "<div class='Pendingwork'><span class='label-success label label-default pull-right'><a href='account_detail.php?id="+result[ls].id+"'>View</a></span>"+
                                    "<a href='#'>"+(ls+1)+". "+result[ls].name+"</a>"+ 
                                    "<div class='upworkdate'>"+
                                       "<p>"+result[ls].industry+"</p>"+
                                    "</div>"+
                                 "</div>";
                   }
                  $('#accounts_list').html(list);
               },
               error: function(xhr, textStatus, errorThrown) {
                   alert('Network Error, Try Later!!');
                   return false;
               }
             });


             $.ajax({
               url: 'backend/getallleads.php',
               type: 'GET',
               async:false,
               success: function(data){
                   var result = JSON.parse(data);
                   var list = "";
                   for(var ls=0; ls<result.length;ls++) {
                        list += "<tr>"+
                                    "<td>"+(ls+1)+". "+result[ls].name+"</td>"+
                                    "<td>"+result[ls].acc+"</td>"+
                                    "<td><a href='leads_detail.php?id="+result[ls].id+"'>View</a></td>"+
                                 "</tr>";
                   }
                  $('#leads_list').html(list);
               },
               error: function(xhr, textStatus, errorThrown) {
                   alert('Network Error, Try Later!!');
                   return false;
               }
             });

             $.ajax({
               url: 'backend/getalloppors.php',
               type: 'GET',
               async:false,
               success: function(data){
                   var result = JSON.parse(data);
                   var list = "";
                   for(var ls=0; ls<result.length;ls++) {
                        list += "<tr>"+
                                    "<td>"+(ls+1)+". "+result[ls].name+"</td>"+
                                    "<td>"+result[ls].stage+"</td>"+
                                    "<td>"+result[ls].source+"</td>"+
                                 "</tr>";
                   }
                  $('#opps_list').html(list);
               },
               error: function(xhr, textStatus, errorThrown) {
                   alert('Network Error, Try Later!!');
                   return false;
               }
             });

             $.ajax({
               url: 'backend/getallevents.php',
               type: 'GET',
               async:false,
               success: function(data){
                   var result = JSON.parse(data);
                   var list = "";
                   for(var ls=0; ls<result.length;ls++) {
                        list += "<div class='work-touchpoint'>"+
                                 "<div class='work-touchpoint-date'>"+
                                    "<span class='day'>"+result[ls].day+"</span>"+
                                    "<span class='month'>"+result[ls].month+"</span>"+
                                 "</div>"+
                                 "</div>"+
                                 "<div class='detailswork'>"+
                                    "<span class='label-custom label label-default pull-right'>"+result[ls].message+"</span>"+
                                    "<a href='#' title='headings'>"+result[ls].message+"</a> <br>"+
                                    "<p>"+result[ls].location+"</p>"+
                                 "</div>";
                   }
                  $('#cal_list').html(list);
               },
               error: function(xhr, textStatus, errorThrown) {
                   alert('Network Error, Try Later!!');
                   return false;
               }
             });

         });
         function dash() {
             $('#m_calendar').monthly({
                 mode: 'event',
                 xmlUrl: 'events.xml'
             }); 
             $('.count-number').counterUp({
                 delay: 10,
                 time: 5000
             });
         }
         dash();         
      </script>
   </body>
</html>