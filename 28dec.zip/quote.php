<?php
   include('includes/auth.inc');
   include('backend/conn.php');
   $op_id = $_GET['id'];
   $accounts = "SELECT * FROM `oppurtunity` WHERE id=$op_id";
   $accounts_exe = $conn->query($accounts);
   $opp_details = $accounts_exe->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CRM | Quotation</title>
      <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
      <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/plugins/lobipanel/lobipanel.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/plugins/pace/flash.css" rel="stylesheet" type="text/css"/>
      <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
      <link href="assets/themify-icons/themify-icons.css" rel="stylesheet" type="text/css"/>
      <link href="assets/dist/css/stylecrm.css" rel="stylesheet" type="text/css"/>
   </head>
   <body class="hold-transition sidebar-mini">
      <div id="preloader">
         <div id="status"></div>
      </div>
      <div class="wrapper">
         <?php 
            include('includes/topbar.inc');
            include('includes/sidebar.inc');
         ?> 
         <div class="content-wrapper">
            <section class="content-header">
               <div class="header-icon">
                  <i class="fa fa-file-text"></i>
               </div>
               <div class="header-title">
                  <h1>Quotation</h1>
                  <small>Issue New Quotation</small>
               </div>
            </section>
            <div class="content" style="background:#ffffff">
               <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                     <div class="x_panel">
                        <div class="x_title">
                           <h2>Invoice</h2>
                           <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                           <div class="row">
                              <div class="col-md-3">
                                 <h3><span class="label label-default">Sent</span></h3>
                              </div>
                              <div class="col-md-9 text-right">
                                 <div class="btn-group">
                                    <a href="#" data-placement="left" data-toggle="tooltip" title="" class="btn btn-default btn-with-tooltip" data-original-title="Edit"><i class="fa fa-pencil-square-o"></i></a>
                                    <a href="" onclick="window.print();" class="btn btn-default btn-with-tooltip" data-toggle="tooltip" title="" data-placement="bottom" data-original-title="Print"><i class="fa fa-print"></i></a>
                                    <a href="#" target="_blank" class="btn btn-default btn-with-tooltip" data-toggle="tooltip" title="" data-placement="bottom" data-original-title="PDF"><i class="fa fa-file-pdf-o"></i></a>
                                    <a href="#" class="btn btn-default btn-with-tooltip" data-toggle="tooltip" title="" data-placement="bottom" data-original-title="Send to customer"><i class="fa fa-envelope"></i></a>
                                 </div>
                              </div>
                           </div>
                           <div class="clearfix"></div>
                           <hr>
                           <div class="row">
                              <div class="col-md-12">
                                 <h4 class="font-medium text-success">
                                    Date: <?php echo date('d-m-Y');?><br>
                                 </h4>
                              </div>
                              <div class="col-md-6">
                                 <h4 class="bold">
                                    <a href="">
                                    <span id="invoice-number">
                                       INV-0000<?php echo $op_id;?>
                                    </span>
                                    </a>
                                 </h4>
                                 <address>
                                    <b style="color:black" class="company-name-formatted"><?php echo $opp_details['name'];?></b><br> 205 Pioneer Industrial Estate,
                                    Jogeshwari (E), Mumbai 400060<br> Mumbai<br> Maharashtra<br> India 400060                        
                                 </address>
                              </div>
                              <div class="col-sm-6 text-right">
                                 <span class="bold">Bill To:</span>
                                 <address>
                                    <a href=""><b><?php echo $opp_details['name'];?></b></a><br> test street<br> test city<br> test state<br> Australia 878888                        
                                 </address>
                                 <p class="no-mbot">
                                    <span class="bold">
                                    Date:                           </span>
                                    23-11-2019                        
                                 </p>
                                 <p class="no-mbot">
                                    <span class="bold">
                                    Expiry Date:                           </span>
                                    23-11-2019                        
                                 </p>
                              </div>
                           </div>
                           <div class="table-responsive">
                              <table class="table table-striped jambo_table bulk_action" id="myTable">
                                 <thead>
                                    <tr class="head">
                                       <th></th>
                                       <th width="20%" class="text-left">Item</th>
                                       <th width="30%" class="text-left">Description</th>
                                       <th width="10%" class="text-left">Qty</th>
                                       <th width="13%" class="text-left">Rate</th>
                                       <th width="12%" class="text-left">Tax</th>
                                       <th width="15%" class="text-left">Amount ()</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr class="main" id="item_list">
                                       <td></td>
                                       <td class="item">
                                          Zn+  
                                       </td>
                                       <td>
                                          <textarea name="description[]" rows="3" id="description_1" class="form-control" placeholder="Description" readonly="true">test</textarea>
                                       </td>
                                       <td class="quantity">
                                          1  
                                       </td>
                                       <td class="rate">
                                          67  
                                       </td>
                                       <td class="tax">
                                          0 
                                       </td>
                                       <td class="amount">
                                          67
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                           <div class="col-md-5 col-md-offset-7">
                              <table class="table table-striped" id="summary">
                                 <tbody>
                                    <tr class="sub">
                                       <td width="80%"><span class="bold">Sub Total :</span>
                                       </td>
                                       <td width="20%" class="subtotal">67     </td>
                                    </tr>
                                    <tr class="sub">
                                       <td width="80%"><span class="bold">Discount (0%) :</span>
                                       </td>
                                       <td width="20%" class="discount_percent">0  </td>
                                    </tr>
                                    <tr class="sub">
                                       <td width="80%"><span class="bold">Adjustment :</span>
                                       </td>
                                       <td class="adjustment">0</td>
                                    </tr>
                                    <tr class="sub">
                                       <td><b>Total :</b>
                                       </td>
                                       <td class="total"><b><span id="currency"><span></span></span></b><b id="total">67</b>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="x_panel">
                        <div class="x_title">
                           <h2>Extra Details</h2>
                           <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                           <div class="form-group">
                              <label for="item_select" class="control-label">Client Note</label>
                              <textarea id="client_note" name="client_note" class="form-control" rows="2" readonly="true"></textarea>
                           </div>
                           <div class="form-group">
                              <label for="item_select" class="control-label">Terms &amp; Conditions</label>
                              <textarea id="terms_and_conditions" name="terms_and_conditions" class="form-control" rows="2" readonly="true"></textarea>
                           </div>
                        </div>
                     </div>
                     <br><br><br>
                  </div>
               </div>
            </div>
         </div>
        <?php include('includes/footer.inc');?>
      </div>
      <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
      <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
      <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
      <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
      <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
      <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
      <script src="assets/dist/js/custom.js" type="text/javascript"></script>
      <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
   </body>
</html>