<?php
date_default_timezone_set("Asia/Kolkata");
$servername = "localhost";
$username = "root";
$password = "solution";
$dbname = "crm";
$conn = new mysqli($servername, $username, $password, $dbname);
